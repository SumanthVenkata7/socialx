from django.contrib import messages
from django.contrib.auth import get_user_model, login
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import F, Q
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils import timezone

from .forms import (
    CommentForm,
    MessageForm,
    PostForm,
    ProfileForm,
    ReelForm,
    RegisterForm,
    StoryForm,
    VideoForm,
)
from .models import Comment, Conversation, Follow, Like, Notification, Post, Profile, Reel, Story, Video

User = get_user_model()
CONTENT_MODELS = {'post': Post, 'video': Video, 'reel': Reel}


def _page(request, queryset, per_page=10):
    return Paginator(queryset, per_page).get_page(request.GET.get('page'))


def _create_notification(recipient, actor, verb, target=None):
    if recipient.pk == actor.pk:
        return
    fields = {'recipient': recipient, 'actor': actor, 'verb': verb}
    if target is not None:
        fields.update(
            content_type=ContentType.objects.get_for_model(target),
            object_id=target.pk,
        )
    Notification.objects.create(**fields)


def _profile_context(profile, request):
    user = profile.user
    return {
        'profile_user': user,
        'profile': profile,
        'posts': user.posts.all()[:30],
        'videos': user.videos.all()[:12],
        'reels': user.reels.all()[:12],
        'followers_count': user.follower_links.count(),
        'following_count': user.following_links.count(),
        'is_following': request.user.is_authenticated and user.follower_links.filter(
            follower=request.user
        ).exists(),
    }


def feed(request):
    if request.user.is_authenticated:
        following_ids = request.user.following_links.values_list('following_id', flat=True)
        posts = Post.objects.filter(Q(user=request.user) | Q(user_id__in=following_ids))
        if not posts.exists():
            posts = Post.objects.all()
        story_users = User.objects.filter(Q(pk=request.user.pk) | Q(pk__in=following_ids))
        suggestions = User.objects.exclude(pk=request.user.pk).exclude(
            pk__in=following_ids
        ).select_related('profile')[:5]
    else:
        posts = Post.objects.all()
        story_users = User.objects.none()
        suggestions = User.objects.all().select_related('profile')[:5]
    stories = Story.objects.filter(user__in=story_users, expires_at__gt=timezone.now()).select_related(
        'user', 'user__profile'
    )
    page_obj = _page(request, posts.select_related('user', 'user__profile'))
    return render(request, 'social/feed.html', {
        'page_obj': page_obj,
        'posts': page_obj.object_list,
        'stories': stories,
        'suggestions': suggestions,
    })


def register(request):
    if request.user.is_authenticated:
        return redirect('feed')
    form = RegisterForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, 'Welcome to GENZI. Your account is ready.')
        return redirect('feed')
    return render(request, 'social/auth.html', {'form': form, 'registering': True})


@login_required
def upload(request):
    forms = {
        'post': PostForm(request.POST or None, request.FILES or None, prefix='post'),
        'story': StoryForm(request.POST or None, request.FILES or None, prefix='story'),
        'video': VideoForm(request.POST or None, request.FILES or None, prefix='video'),
        'reel': ReelForm(request.POST or None, request.FILES or None, prefix='reel'),
    }
    if request.method == 'POST':
        kind = request.POST.get('kind')
        form = forms.get(kind)
        if form is None:
            messages.error(request, 'Choose a valid upload type.')
        elif form.is_valid():
            item = form.save(commit=False)
            item.user = request.user
            item.save()
            messages.success(request, 'Your content has been shared.')
            return redirect('feed')
    return render(request, 'social/upload.html', {'forms': forms, 'active_kind': request.POST.get('kind', 'post')})


@login_required
def edit_post(request, post_id):
    post = get_object_or_404(Post, pk=post_id, user=request.user)
    form = PostForm(request.POST or None, request.FILES or None, instance=post, prefix='post')
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Your post has been updated.')
        return redirect('post_detail', post_id=post.pk)
    return render(request, 'social/post_edit.html', {'form': form, 'post': post})


@login_required
@require_POST
def delete_post(request, post_id):
    post = get_object_or_404(Post, pk=post_id, user=request.user)
    post.delete()
    messages.success(request, 'Your post has been deleted.')
    return redirect('feed')


def video_home(request):
    videos = Video.objects.select_related('user', 'user__profile')
    query = request.GET.get('q', '').strip()
    if query:
        videos = videos.filter(
            Q(title__icontains=query) | Q(description__icontains=query) | Q(user__username__icontains=query)
        )
    page_obj = _page(request, videos)
    return render(request, 'social/videos.html', {'page_obj': page_obj, 'videos': page_obj.object_list, 'query': query})


def video_detail(request, video_id):
    video = get_object_or_404(Video.objects.select_related('user', 'user__profile'), pk=video_id)
    key = f'viewed_video_{video.pk}'
    if key not in request.session:
        Video.objects.filter(pk=video.pk).update(views=F('views') + 1)
        request.session[key] = True
        video.refresh_from_db(fields=('views',))
    comments = video.comments.select_related('user', 'user__profile').filter(parent__isnull=True)
    recommendations = Video.objects.exclude(pk=video.pk).select_related('user', 'user__profile')[:6]
    return render(request, 'social/video_detail.html', {
        'video': video,
        'comments': comments,
        'comment_form': CommentForm(),
        'recommendations': recommendations,
    })


def reels(request):
    page_obj = _page(request, Reel.objects.select_related('user', 'user__profile'), per_page=12)
    return render(request, 'social/reels.html', {'page_obj': page_obj, 'reels': page_obj.object_list})


def post_detail(request, post_id):
    post = get_object_or_404(Post.objects.select_related('user', 'user__profile'), pk=post_id)
    comments = post.comments.select_related('user', 'user__profile').filter(parent__isnull=True)
    return render(request, 'social/post_detail.html', {
        'post': post,
        'comments': comments,
        'comment_form': CommentForm(),
    })


def story_detail(request, story_id):
    story = get_object_or_404(
        Story.objects.select_related('user', 'user__profile'),
        pk=story_id,
        expires_at__gt=timezone.now(),
    )
    return render(request, 'social/story_detail.html', {'story': story})


@login_required
def edit_profile(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    form = ProfileForm(request.POST or None, request.FILES or None, instance=profile)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Your profile has been updated.')
        return redirect('profile', username=request.user.username)
    return render(request, 'social/profile_edit.html', {'form': form})


def profile(request, username):
    target_user = get_object_or_404(User, username=username)
    profile_obj, _ = Profile.objects.get_or_create(user=target_user)
    return render(request, 'social/profile.html', _profile_context(profile_obj, request))


def follow_list(request, username, list_type):
    target_user = get_object_or_404(User, username=username)
    if list_type == 'followers':
        users = User.objects.filter(following_links__following=target_user).select_related('profile')
        heading = 'Followers'
    else:
        users = User.objects.filter(following_links__follower=target_user).select_related('profile')
        heading = 'Following'
    return render(request, 'social/user_list.html', {'users': users, 'heading': heading, 'profile_user': target_user})


@login_required
@require_POST
def toggle_follow(request, username):
    target = get_object_or_404(User, username=username)
    if target.pk == request.user.pk:
        messages.error(request, 'You cannot follow yourself.')
    else:
        follow, created = Follow.objects.get_or_create(follower=request.user, following=target)
        if created:
            _create_notification(target, request.user, 'started following you')
            messages.success(request, f'You are now following @{target.username}.')
        else:
            follow.delete()
            messages.info(request, f'You unfollowed @{target.username}.')
    return redirect('profile', username=username)


@login_required
@require_POST
def toggle_like(request, content_type, object_id):
    if content_type not in CONTENT_MODELS:
        raise Http404
    model = CONTENT_MODELS[content_type]
    target = get_object_or_404(model, pk=object_id)
    ctype = ContentType.objects.get_for_model(model)
    like, created = Like.objects.get_or_create(user=request.user, content_type=ctype, object_id=target.pk)
    if created:
        _create_notification(target.user, request.user, 'liked your content', target)
    else:
        like.delete()
    liked = created
    likes_count = Like.objects.filter(content_type=ctype, object_id=target.pk).count()
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', ''):
        return JsonResponse({
            'liked': liked,
            'likes_count': likes_count,
            'content_type': content_type,
            'object_id': target.pk,
        })
    next_url = request.POST.get('next', '')
    if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
        return redirect(next_url)
    if content_type == 'video':
        return redirect('video_detail', video_id=target.pk)
    if content_type == 'post':
        return redirect('post_detail', post_id=target.pk)
    return redirect('reels')


@login_required
@require_POST
def add_comment(request, content_type, object_id):
    if content_type not in CONTENT_MODELS:
        raise Http404
    target = get_object_or_404(CONTENT_MODELS[content_type], pk=object_id)
    form = CommentForm(request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.user = request.user
        comment.content_type = ContentType.objects.get_for_model(target)
        comment.object_id = target.pk
        parent_id = request.POST.get('parent')
        if parent_id:
            comment.parent = get_object_or_404(
                Comment, pk=parent_id, content_type=comment.content_type, object_id=target.pk
            )
        comment.save()
        _create_notification(target.user, request.user, 'commented on your content', target)
        messages.success(request, 'Comment added.')
    else:
        for error in form.errors.get('body', []):
            messages.error(request, error)
    if content_type == 'video':
        return redirect('video_detail', video_id=target.pk)
    if content_type == 'post':
        return redirect('post_detail', post_id=target.pk)
    return redirect('reels')


@login_required
@require_POST
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment.objects.select_related('content_type'), pk=comment_id)
    if comment.user_id != request.user.pk:
        raise Http404
    content_type = next(
        (name for name, model in CONTENT_MODELS.items()
         if comment.content_type_id == ContentType.objects.get_for_model(model).pk),
        None,
    )
    if content_type is None:
        raise Http404
    object_id = comment.object_id
    comment.delete()
    messages.success(request, 'Your comment has been deleted.')
    if content_type == 'video':
        return redirect('video_detail', video_id=object_id)
    if content_type == 'post':
        return redirect('post_detail', post_id=object_id)
    return redirect('reels')


def search(request):
    query = request.GET.get('q', '').strip()
    users = User.objects.filter(username__icontains=query).select_related('profile')[:10] if query else User.objects.none()
    videos = Video.objects.filter(
        Q(title__icontains=query) | Q(description__icontains=query)
    ).select_related('user', 'user__profile')[:12] if query else Video.objects.none()
    posts = Post.objects.filter(caption__icontains=query).select_related('user', 'user__profile')[:12] if query else Post.objects.none()
    return render(request, 'social/search.html', {'query': query, 'users': users, 'videos': videos, 'posts': posts})


@login_required
def notifications(request):
    items = request.user.notifications.select_related('actor', 'actor__profile')
    if request.method == 'POST':
        items.filter(read_at__isnull=True).update(read_at=timezone.now())
        return redirect('notifications')
    return render(request, 'social/notifications.html', {'notifications': items[:50]})


@login_required
def inbox(request):
    conversations = request.user.conversations.prefetch_related('participants', 'messages').all()
    return render(request, 'social/inbox.html', {'conversations': conversations})


@login_required
@require_POST
def start_conversation(request, username):
    other = get_object_or_404(User, username=username)
    if other.pk == request.user.pk:
        messages.error(request, 'You cannot start a conversation with yourself.')
        return redirect('inbox')
    existing = Conversation.objects.filter(participants=request.user).filter(participants=other)
    conversation_obj = next(
        (item for item in existing if item.participants.count() == 2),
        None,
    )
    if conversation_obj is None:
        with transaction.atomic():
            conversation_obj = Conversation.objects.create()
            conversation_obj.participants.add(request.user, other)
    return redirect('conversation', conversation_id=conversation_obj.pk)


@login_required
def conversation(request, conversation_id):
    conversation_obj = get_object_or_404(
        Conversation.objects.prefetch_related('participants', 'messages__sender'),
        pk=conversation_id,
        participants=request.user,
    )
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            Message = conversation_obj.messages.model
            Message.objects.create(
                conversation=conversation_obj, sender=request.user, body=form.cleaned_data['body']
            )
            conversation_obj.save(update_fields=('updated_at',))
            return redirect('conversation', conversation_id=conversation_obj.pk)
    else:
        form = MessageForm()
    conversation_obj.messages.exclude(sender=request.user).filter(read_at__isnull=True).update(
        read_at=timezone.now()
    )
    other_participants = conversation_obj.participants.exclude(pk=request.user.pk)
    return render(request, 'social/conversation.html', {
        'conversation': conversation_obj,
        'other_participants': other_participants,
        'form': form,
    })
