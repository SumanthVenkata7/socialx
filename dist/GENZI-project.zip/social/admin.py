from django.contrib import admin

from .models import Comment, Conversation, Follow, Like, Message, Notification, Post, Profile, Reel, Story, Video


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at')
    search_fields = ('user__username', 'bio')
    ordering = ('user__username',)


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('user', 'caption', 'image', 'video', 'created_at')
    search_fields = ('user__username', 'caption')
    list_filter = ('created_at',)
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)


@admin.register(Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'views', 'created_at')
    search_fields = ('title', 'description', 'user__username')
    list_filter = ('created_at',)
    ordering = ('-created_at',)
    readonly_fields = ('views', 'created_at')


@admin.register(Reel)
class ReelAdmin(admin.ModelAdmin):
    list_display = ('user', 'caption', 'file', 'views', 'created_at')
    search_fields = ('user__username', 'caption')
    ordering = ('-created_at',)
    readonly_fields = ('views', 'created_at')


@admin.register(Story)
class StoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'media_type', 'created_at', 'expires_at')
    list_filter = ('media_type', 'expires_at')
    search_fields = ('user__username', 'caption')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)


@admin.register(Follow)
class FollowAdmin(admin.ModelAdmin):
    list_display = ('follower', 'following', 'created_at')
    search_fields = ('follower__username', 'following__username')
    list_filter = ('created_at',)
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    list_display = ('user', 'content_type', 'object_id', 'created_at')
    search_fields = ('user__username',)
    list_filter = ('content_type', 'created_at')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('user', 'content_type', 'object_id', 'created_at')
    search_fields = ('body', 'user__username')
    list_filter = ('content_type', 'created_at')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('recipient', 'actor', 'verb', 'created_at', 'read_at')
    list_filter = ('verb', 'created_at', 'read_at')
    search_fields = ('recipient__username', 'actor__username', 'verb')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)


class MessageInline(admin.TabularInline):
    model = Message
    extra = 0
    readonly_fields = ('sender', 'body', 'created_at', 'read_at')
    can_delete = False


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('id', 'created_at', 'updated_at')
    filter_horizontal = ('participants',)
    inlines = (MessageInline,)


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'conversation', 'body', 'created_at', 'read_at')
    search_fields = ('sender__username', 'body')
    list_filter = ('created_at', 'read_at')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'read_at')
