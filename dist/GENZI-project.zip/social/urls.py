from django.contrib.auth import views as auth_views
from django.urls import path

from . import views
from .forms import LoginForm

urlpatterns = [
    path('', views.feed, name='feed'),
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(
        template_name='social/auth.html', authentication_form=LoginForm
    ), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('upload/', views.upload, name='upload'),
    path('post/<int:post_id>/edit/', views.edit_post, name='edit_post'),
    path('post/<int:post_id>/delete/', views.delete_post, name='delete_post'),
    path('videos/', views.video_home, name='video_home'),
    path('videos/<int:video_id>/', views.video_detail, name='video_detail'),
    path('reels/', views.reels, name='reels'),
    path('post/<int:post_id>/', views.post_detail, name='post_detail'),
    path('story/<int:story_id>/', views.story_detail, name='story_detail'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),
    path('u/<str:username>/', views.profile, name='profile'),
    path('u/<str:username>/followers/', views.follow_list, {'list_type': 'followers'}, name='followers'),
    path('u/<str:username>/following/', views.follow_list, {'list_type': 'following'}, name='following'),
    path('follow/<str:username>/', views.toggle_follow, name='toggle_follow'),
    path('like/<str:content_type>/<int:object_id>/', views.toggle_like, name='toggle_like'),
    path('comment/<str:content_type>/<int:object_id>/', views.add_comment, name='add_comment'),
    path('comment/<int:comment_id>/delete/', views.delete_comment, name='delete_comment'),
    path('search/', views.search, name='search'),
    path('notifications/', views.notifications, name='notifications'),
    path('messages/', views.inbox, name='inbox'),
    path('messages/new/<str:username>/', views.start_conversation, name='start_conversation'),
    path('messages/<int:conversation_id>/', views.conversation, name='conversation'),
]
