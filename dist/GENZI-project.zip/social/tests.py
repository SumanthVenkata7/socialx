from io import BytesIO
from tempfile import TemporaryDirectory

from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from django.db import IntegrityError, transaction
from django.http import JsonResponse
from django.test import TestCase, override_settings
from django.urls import reverse
from django.core.files.uploadedfile import SimpleUploadedFile
from PIL import Image

from .models import Comment, Conversation, Follow, Like, Post, UserProfile, Video

User = get_user_model()


class GenziFeatureTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='maya', password='GenziTestPass!2026')
        self.other = User.objects.create_user(username='river', password='GenziTestPass!2026')

    def test_public_feed_and_video_pages_render(self):
        self.assertEqual(self.client.get(reverse('feed')).status_code, 200)
        self.assertEqual(self.client.get(reverse('video_home')).status_code, 200)
        self.assertEqual(self.client.get(reverse('reels')).status_code, 200)

    def test_register_creates_authenticated_user_and_profile(self):
        response = self.client.post(reverse('register'), {
            'username': 'newcreator',
            'email': 'newcreator@example.com',
            'password1': 'Unique-GENZI-Password-2026!',
            'password2': 'Unique-GENZI-Password-2026!',
        })
        self.assertRedirects(response, reverse('feed'))
        self.assertTrue(User.objects.get(username='newcreator').profile)

    def test_follow_toggle_is_idempotent_and_blocks_self_follow(self):
        self.client.force_login(self.user)
        url = reverse('toggle_follow', args=(self.other.username,))
        self.client.post(url)
        self.client.post(url)
        self.assertEqual(Follow.objects.filter(follower=self.user, following=self.other).count(), 0)
        self.client.post(reverse('toggle_follow', args=(self.user.username,)))
        self.assertFalse(Follow.objects.filter(follower=self.user, following=self.user).exists())

    def test_like_toggle_adds_and_removes_like(self):
        post = Post.objects.create(user=self.other, caption='A little update')
        self.client.force_login(self.user)
        url = reverse('toggle_like', args=('post', post.pk))
        self.client.post(url)
        self.assertEqual(post.likes.count(), 1)
        self.client.post(url)
        self.assertEqual(post.likes.count(), 0)

    def test_comment_is_attached_to_the_correct_post(self):
        post = Post.objects.create(user=self.other, caption='A little update')
        self.client.force_login(self.user)
        response = self.client.post(
            reverse('add_comment', args=('post', post.pk)), {'body': 'Nice post'}
        )
        self.assertRedirects(response, reverse('post_detail', args=(post.pk,)))
        self.assertEqual(post.comments.get().body, 'Nice post')

    def test_conversation_is_private_to_participants(self):
        conversation = Conversation.objects.create()
        conversation.participants.add(self.user, self.other)
        outsider = User.objects.create_user(username='outsider', password='GenziTestPass!2026')
        self.client.force_login(outsider)
        self.assertEqual(self.client.get(reverse('conversation', args=(conversation.pk,))).status_code, 404)

    def test_video_view_count_increments_once_per_session(self):
        video = Video.objects.create(user=self.other, title='Test video', file='videos/test.mp4')
        self.client.get(reverse('video_detail', args=(video.pk,)))
        self.client.get(reverse('video_detail', args=(video.pk,)))
        video.refresh_from_db()
        self.assertEqual(video.views, 1)

    def test_follow_database_constraint_prevents_duplicate_edges(self):
        Follow.objects.create(follower=self.user, following=self.other)
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Follow.objects.create(follower=self.user, following=self.other)

    def test_comments_support_replies(self):
        post = Post.objects.create(user=self.other, caption='A little update')
        root = Comment.objects.create(
            user=self.user, content_type=ContentType.objects.get_for_model(post),
            object_id=post.pk, body='First comment',
        )
        reply = Comment.objects.create(
            user=self.other, content_type=ContentType.objects.get_for_model(post),
            object_id=post.pk, parent=root, body='Reply',
        )
        self.assertEqual(root.replies.get(), reply)

    def test_user_profile_model_is_created_for_each_registered_user(self):
        self.assertIsInstance(self.user.profile, UserProfile)

    def test_profile_page_repairs_missing_profile_row(self):
        self.user.profile.delete()
        response = self.client.get(reverse('profile', args=(self.user.username,)))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(UserProfile.objects.filter(user=self.user).exists())

    def test_feed_shows_posts_from_followed_users(self):
        Follow.objects.create(follower=self.user, following=self.other)
        post = Post.objects.create(user=self.other, caption='Followed creator post')
        self.client.force_login(self.user)
        response = self.client.get(reverse('feed'))
        self.assertContains(response, post.caption)

    def test_post_edit_and_delete_are_restricted_to_the_owner(self):
        post = Post.objects.create(user=self.user, caption='Original')
        self.client.force_login(self.other)
        self.assertEqual(
            self.client.post(reverse('edit_post', args=(post.pk,)), {'post-caption': 'Stolen'}).status_code,
            404,
        )
        self.assertEqual(self.client.post(reverse('delete_post', args=(post.pk,))).status_code, 404)
        self.client.force_login(self.user)
        response = self.client.post(
            reverse('edit_post', args=(post.pk,)), {'post-caption': 'Updated'}
        )
        self.assertRedirects(response, reverse('post_detail', args=(post.pk,)))
        post.refresh_from_db()
        self.assertEqual(post.caption, 'Updated')
        self.client.post(reverse('delete_post', args=(post.pk,)))
        self.assertFalse(Post.objects.filter(pk=post.pk).exists())

    def test_comment_delete_is_restricted_to_author_and_uses_post_redirect(self):
        post = Post.objects.create(user=self.other, caption='Original')
        comment = Comment.objects.create(
            user=self.user, content_type=ContentType.objects.get_for_model(post),
            object_id=post.pk, body='Mine',
        )
        self.client.force_login(self.other)
        self.assertEqual(self.client.post(reverse('delete_comment', args=(comment.pk,))).status_code, 404)
        self.client.force_login(self.user)
        response = self.client.post(reverse('delete_comment', args=(comment.pk,)))
        self.assertRedirects(response, reverse('post_detail', args=(post.pk,)))
        self.assertFalse(Comment.objects.filter(pk=comment.pk).exists())

    def test_ajax_like_returns_targeted_updated_count(self):
        post = Post.objects.create(user=self.other, caption='Like me')
        self.client.force_login(self.user)
        response = self.client.post(
            reverse('toggle_like', args=('post', post.pk)),
            HTTP_ACCEPT='application/json',
            HTTP_X_REQUESTED_WITH='XMLHttpRequest',
        )
        self.assertIsInstance(response, JsonResponse)
        self.assertEqual(response.json(), {
            'liked': True, 'likes_count': 1, 'content_type': 'post', 'object_id': post.pk,
        })

    def test_message_creation_requires_conversation_membership(self):
        conversation = Conversation.objects.create()
        conversation.participants.add(self.user, self.other)
        self.client.force_login(self.user)
        response = self.client.post(
            reverse('conversation', args=(conversation.pk,)), {'body': 'Hello'}
        )
        self.assertRedirects(response, reverse('conversation', args=(conversation.pk,)))
        self.assertEqual(conversation.messages.get().sender, self.user)

    def test_admin_registers_social_models(self):
        from django.contrib import admin

        for model in (UserProfile, Post, Follow, Like, Comment, Video, Conversation):
            self.assertIn(model, admin.site._registry)

    def test_post_image_and_video_uploads_use_media_storage(self):
        image_buffer = BytesIO()
        Image.new('RGB', (2, 2), color='purple').save(image_buffer, format='PNG')
        image_upload = SimpleUploadedFile('post.png', image_buffer.getvalue(), content_type='image/png')
        video_upload = SimpleUploadedFile('clip.mp4', b'fake video bytes', content_type='video/mp4')

        self.client.force_login(self.user)
        with TemporaryDirectory() as media_root:
            with override_settings(MEDIA_ROOT=media_root):
                image_response = self.client.post(reverse('upload'), {
                    'kind': 'post',
                    'post-caption': 'Image post',
                    'post-image': image_upload,
                })
                self.assertRedirects(image_response, reverse('feed'))
                post = Post.objects.get(caption='Image post')
                self.assertTrue(post.image.name.startswith('posts/'))

                video_response = self.client.post(reverse('upload'), {
                    'kind': 'video',
                    'video-title': 'First video',
                    'video-description': 'A test upload',
                    'video-file': video_upload,
                })
                self.assertRedirects(video_response, reverse('feed'))
                video = Video.objects.get(title='First video')
                self.assertTrue(video.file.name.startswith('videos/'))

    def test_admin_model_changelist_is_accessible_to_staff(self):
        self.user.is_staff = True
        self.user.is_superuser = True
        self.user.save(update_fields=('is_staff', 'is_superuser'))
        self.client.force_login(self.user)
        response = self.client.get(reverse('admin:social_post_changelist'))
        self.assertEqual(response.status_code, 200)
