from django import template
from django.contrib.contenttypes.models import ContentType

from social.models import Like

register = template.Library()


@register.filter
def liked_by(obj, user):
    if not user or not user.is_authenticated:
        return False
    content_type = ContentType.objects.get_for_model(obj)
    return Like.objects.filter(user=user, content_type=content_type, object_id=obj.pk).exists()


@register.filter
def avatar_url(user):
    profile = getattr(user, 'profile', None)
    if profile and profile.avatar:
        return profile.avatar.url
    return ''
