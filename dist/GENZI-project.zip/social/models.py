from pathlib import Path

from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey, GenericRelation
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from django.db import models
from django.db.models import Q
from django.utils import timezone


IMAGE_EXTENSIONS = ('jpg', 'jpeg', 'png', 'webp')
VIDEO_EXTENSIONS = ('mp4', 'webm')
MAX_IMAGE_SIZE = 10 * 1024 * 1024
MAX_VIDEO_SIZE = 250 * 1024 * 1024


def validate_image_size(upload):
    if upload.size > MAX_IMAGE_SIZE:
        raise ValidationError('Images must be 10 MB or smaller.')


def validate_video_size(upload):
    if upload.size > MAX_VIDEO_SIZE:
        raise ValidationError('Videos must be 250 MB or smaller.')


def image_validators():
    return [FileExtensionValidator(allowed_extensions=IMAGE_EXTENSIONS), validate_image_size]


def video_validators():
    return [FileExtensionValidator(allowed_extensions=VIDEO_EXTENSIONS), validate_video_size]


class UserProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile')
    avatar = models.ImageField(upload_to='profiles/', blank=True, validators=image_validators())
    bio = models.CharField(max_length=180, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'@{self.user.username}'


Profile = UserProfile


class Post(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='posts')
    caption = models.CharField(max_length=2200, blank=True)
    image = models.ImageField(upload_to='posts/', blank=True, validators=image_validators())
    video = models.FileField(upload_to='videos/posts/', blank=True, validators=video_validators())
    likes = GenericRelation('Like', related_query_name='post')
    comments = GenericRelation('Comment', related_query_name='post')
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ('-created_at',)

    def clean(self):
        if self.image and self.video:
            raise ValidationError('A post can contain an image or a video, not both.')
        if not (self.caption or self.image or self.video):
            raise ValidationError('Add a caption, image, or video.')

    def __str__(self):
        return f'Post by {self.user.username} at {self.created_at:%Y-%m-%d %H:%M}'


class Story(models.Model):
    class MediaType(models.TextChoices):
        IMAGE = 'image', 'Image'
        VIDEO = 'video', 'Video'

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='stories')
    media = models.FileField(upload_to='stories/', validators=[FileExtensionValidator(
        allowed_extensions=IMAGE_EXTENSIONS + VIDEO_EXTENSIONS
    )])
    media_type = models.CharField(max_length=8, choices=MediaType.choices)
    caption = models.CharField(max_length=220, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(db_index=True)

    class Meta:
        ordering = ('-created_at',)

    def save(self, *args, **kwargs):
        if not self.expires_at:
            self.expires_at = timezone.now() + timezone.timedelta(hours=24)
        super().save(*args, **kwargs)

    def clean(self):
        suffix = Path(self.media.name).suffix.lower().lstrip('.')
        expected = IMAGE_EXTENSIONS if self.media_type == self.MediaType.IMAGE else VIDEO_EXTENSIONS
        if suffix and suffix not in expected:
            raise ValidationError({'media': 'The selected file type does not match the story media type.'})
        if self.media and self.media.size > (MAX_IMAGE_SIZE if self.media_type == self.MediaType.IMAGE else MAX_VIDEO_SIZE):
            raise ValidationError({'media': 'This file exceeds the permitted upload size.'})


class Video(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='videos')
    title = models.CharField(max_length=160)
    description = models.TextField(max_length=5000, blank=True)
    file = models.FileField(upload_to='videos/', validators=video_validators())
    thumbnail = models.ImageField(upload_to='videos/thumbnails/', blank=True, validators=image_validators())
    likes = GenericRelation('Like', related_query_name='video')
    comments = GenericRelation('Comment', related_query_name='video')
    views = models.PositiveBigIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ('-created_at',)

    def __str__(self):
        return self.title


class Reel(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reels')
    caption = models.CharField(max_length=2200, blank=True)
    file = models.FileField(upload_to='reels/', validators=video_validators())
    thumbnail = models.ImageField(upload_to='reels/thumbnails/', blank=True, validators=image_validators())
    likes = GenericRelation('Like', related_query_name='reel')
    comments = GenericRelation('Comment', related_query_name='reel')
    views = models.PositiveBigIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ('-created_at',)

    def __str__(self):
        return f'Reel by {self.user.username}'


class Like(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='likes')
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveBigIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=('user', 'content_type', 'object_id'), name='unique_user_like')
        ]
        indexes = [models.Index(fields=('content_type', 'object_id'), name='like_target_idx')]


class Comment(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='comments')
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveBigIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='replies')
    body = models.CharField(max_length=1200)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('created_at',)
        indexes = [
            models.Index(fields=('content_type', 'object_id', 'created_at'), name='comment_target_idx')
        ]


class Follow(models.Model):
    follower = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='following_links')
    following = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='follower_links')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=('follower', 'following'), name='unique_user_follow'),
            models.CheckConstraint(condition=~Q(follower=models.F('following')), name='prevent_self_follow'),
        ]


class Notification(models.Model):
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_notifications'
    )
    verb = models.CharField(max_length=40)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True, blank=True)
    object_id = models.PositiveBigIntegerField(null=True, blank=True)
    target = GenericForeignKey('content_type', 'object_id')
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ('-created_at',)


class Conversation(models.Model):
    participants = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='conversations')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ('-updated_at',)

    def __str__(self):
        return f'Conversation {self.pk}'


class Message(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='messages')
    body = models.CharField(max_length=4000)
    created_at = models.DateTimeField(auto_now_add=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ('created_at',)
        indexes = [models.Index(fields=('conversation', 'created_at'), name='message_thread_idx')]
