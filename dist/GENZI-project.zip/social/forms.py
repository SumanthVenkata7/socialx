from pathlib import Path

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.core.exceptions import ValidationError

from .models import (
    IMAGE_EXTENSIONS,
    MAX_IMAGE_SIZE,
    MAX_VIDEO_SIZE,
    VIDEO_EXTENSIONS,
    Comment,
    Post,
    Profile,
    Reel,
    Story,
    Video,
)

User = get_user_model()


class RegisterForm(UserCreationForm):
    email = forms.EmailField()

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username', 'email')

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise ValidationError('An account with this email already exists.')
        return email


class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'autocomplete': 'username'}))


class ProfileForm(forms.ModelForm):
    username = forms.CharField(max_length=150)
    email = forms.EmailField()

    class Meta:
        model = Profile
        fields = ('avatar', 'bio')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].initial = self.instance.user.username
        self.fields['email'].initial = self.instance.user.email

    def clean_username(self):
        username = self.cleaned_data['username'].strip()
        if User.objects.exclude(pk=self.instance.user_id).filter(username__iexact=username).exists():
            raise ValidationError('That username is already taken.')
        return username

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.exclude(pk=self.instance.user_id).filter(email__iexact=email).exists():
            raise ValidationError('That email is already in use.')
        return email

    def save(self, commit=True):
        profile = super().save(commit=commit)
        if commit:
            profile.user.username = self.cleaned_data['username']
            profile.user.email = self.cleaned_data['email']
            profile.user.save(update_fields=('username', 'email'))
        return profile


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('caption', 'image', 'video')
        widgets = {'caption': forms.Textarea(attrs={'rows': 3})}

    def clean(self):
        cleaned = super().clean()
        image, video = cleaned.get('image'), cleaned.get('video')
        if image and video:
            raise ValidationError('Choose an image or a video for one post.')
        if not (image or video or cleaned.get('caption')):
            raise ValidationError('Add a caption, image, or video.')
        return cleaned


class StoryForm(forms.ModelForm):
    class Meta:
        model = Story
        fields = ('media', 'media_type', 'caption')

    def clean_media(self):
        media = self.cleaned_data['media']
        suffix = Path(media.name).suffix.lower().lstrip('.')
        media_type = self.data.get(self.add_prefix('media_type'), Story.MediaType.IMAGE)
        allowed = IMAGE_EXTENSIONS if media_type == Story.MediaType.IMAGE else VIDEO_EXTENSIONS
        max_size = MAX_IMAGE_SIZE if media_type == Story.MediaType.IMAGE else MAX_VIDEO_SIZE
        if suffix not in allowed:
            raise ValidationError('Choose a file type that matches the selected media type.')
        if media.size > max_size:
            raise ValidationError('This file exceeds the permitted upload size.')
        return media


class VideoForm(forms.ModelForm):
    class Meta:
        model = Video
        fields = ('title', 'description', 'file', 'thumbnail')
        widgets = {'description': forms.Textarea(attrs={'rows': 4})}


class ReelForm(forms.ModelForm):
    class Meta:
        model = Reel
        fields = ('caption', 'file', 'thumbnail')
        widgets = {'caption': forms.Textarea(attrs={'rows': 3})}


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ('body',)
        widgets = {'body': forms.TextInput(attrs={'placeholder': 'Write a comment…', 'maxlength': 1200})}


class MessageForm(forms.Form):
    body = forms.CharField(max_length=4000, widget=forms.Textarea(attrs={'rows': 2, 'placeholder': 'Message…'}))
