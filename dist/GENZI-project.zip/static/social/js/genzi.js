document.addEventListener('DOMContentLoaded', () => {
  const tabs = document.querySelectorAll('.upload-tab');
  const panels = document.querySelectorAll('.upload-form');
  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      tabs.forEach((item) => item.classList.toggle('active', item === tab));
      panels.forEach((panel) => panel.classList.toggle('is-hidden', panel.dataset.panel !== tab.dataset.tab));
    });
  });

  document.querySelectorAll('.share-button').forEach((button) => {
    button.addEventListener('click', async () => {
      const url = button.dataset.shareUrl;
      try {
        if (navigator.share) {
          await navigator.share({ title: 'GENZI', url });
        } else if (navigator.clipboard) {
          await navigator.clipboard.writeText(url);
          showToast('Link copied to clipboard.');
        } else {
          showToast('Sharing is not available in this browser.');
        }
      } catch (error) {
        if (error.name !== 'AbortError') showToast('Could not share this link.');
      }
    });
  });

  document.querySelectorAll('.like-form').forEach((form) => {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = form.querySelector('button');
      button.disabled = true;
      try {
        const response = await fetch(form.action, {
          method: 'POST',
          body: new FormData(form),
          credentials: 'same-origin',
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
          },
        });
        if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) {
          throw new Error('Like request failed.');
        }
        const result = await response.json();
        button.classList.toggle('liked', result.liked);
        button.setAttribute('aria-pressed', String(result.liked));
        const iconText = Array.from(button.childNodes).find((node) => node.nodeType === Node.TEXT_NODE);
        if (iconText) iconText.textContent = button.querySelector('[data-like-count]')
          ? `${result.liked ? '♥' : '♡'} `
          : (result.liked ? '♥' : '♡');
        const counterKey = `${result.content_type}:${result.object_id}`;
        document.querySelectorAll(`[data-like-count="${counterKey}"]`).forEach((counter) => {
          counter.textContent = counter.classList.contains('action-count')
            ? `${result.likes_count} likes`
            : result.likes_count;
        });
      } catch (error) {
        showToast('Could not update your like. Please try again.');
      } finally {
        button.disabled = false;
      }
    });
  });

  document.querySelectorAll('form[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });

  document.querySelectorAll('.flash').forEach((notice) => {
    window.setTimeout(() => notice.classList.add('flash-dismissed'), 5000);
  });

  function showToast(text) {
    const toast = document.createElement('div');
    toast.className = 'share-toast';
    toast.textContent = text;
    document.body.append(toast);
    window.setTimeout(() => toast.remove(), 2800);
  }
});
